ZED STORE Android layihəsi

Bu paket Android Studio layihəsinin mənbə kodudur; hazır APK faylı deyil.
Bu iş mühitində Android SDK/Gradle qurulmadığı üçün APK binary faylını burada kompilyasiya etmək mümkün olmadı.

APK yaratmaq:
1. Layihə qovluğunu Android Studio ilə açın.
2. Android SDK Platform 35 və uyğun Android Gradle Plugin komponentlərinin quraşdırılmasına icazə verin.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
4. APK adətən app/build/outputs/apk/debug/app-debug.apk yolunda yaranır.
5. APK-nı telefona köçürüb quraşdırın.

Tətbiq kalkulyator HTML faylını APK daxilində saxlayır və WebView vasitəsilə açır; gündəlik istifadə üçün Chrome və ZArchiver açmaq lazım olmayacaq.
