package az.zedstore.birmarket;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

public class MainActivity extends Activity {
    private WebView webView;
    private View splashView;
    private boolean pageReady = false;
    private boolean minimumSplashTimePassed = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(5, 7, 12));
        window.setNavigationBarColor(Color.rgb(5, 7, 12));
        window.getDecorView().setSystemUiVisibility(0);

        ImageView splash = new ImageView(this);
        splash.setImageResource(R.drawable.zed_store_splash);
        splash.setScaleType(ImageView.ScaleType.FIT_CENTER);
        splash.setBackgroundColor(Color.rgb(5, 7, 12));
        splashView = splash;
        setContentView(splashView);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243, 246, 251));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                showAppIfReady();
            }
        });

        // Keep the branded opening screen visible briefly, while the calculator loads.
        handler.postDelayed(() -> {
            minimumSplashTimePassed = true;
            showAppIfReady();
        }, 900);

        // Failsafe: never leave the user on the splash screen indefinitely.
        handler.postDelayed(() -> {
            if (!isFinishing() && !isDestroyed()) {
                setContentView(webView);
            }
        }, 5000);

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void showAppIfReady() {
        if (pageReady && minimumSplashTimePassed && webView != null && !isFinishing()) {
            setContentView(webView);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
